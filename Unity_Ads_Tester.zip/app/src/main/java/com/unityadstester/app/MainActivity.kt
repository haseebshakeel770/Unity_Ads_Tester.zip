package com.unityadstester.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize once at app start (guarded against duplicates inside AdsManager).
        AdsManager.initialize(applicationContext)
        setContent { TesterApp() }
    }

    override fun onDestroy() {
        if (isFinishing) AdsManager.destroyBanner()
        super.onDestroy()
    }
}

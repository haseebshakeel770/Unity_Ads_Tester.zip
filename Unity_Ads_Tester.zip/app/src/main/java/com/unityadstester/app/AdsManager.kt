package com.unityadstester.app

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.ads.metadata.MetaData
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AdState { IDLE, LOADING, LOADED, SHOWING, COMPLETED, FAILED }

private val mainHandler = Handler(Looper.getMainLooper())
private fun ui(block: () -> Unit) {
    if (Looper.myLooper() == Looper.getMainLooper()) block() else mainHandler.post(block)
}

/** One full-screen ad format (interstitial or rewarded). */
class AdSlot(val name: String, val placementId: String, val rewarded: Boolean) {
    var state by mutableStateOf(AdState.IDLE)
    var message by mutableStateOf("Not loaded")

    val canLoad: Boolean
        get() = !AdsManager.initializing &&
            (state == AdState.IDLE || state == AdState.COMPLETED || state == AdState.FAILED)

    fun requestLoad(context: Context) {
        if (!canLoad) return
        AdsManager.whenReady(context) { load() }
    }

    fun load() {
        if (placementId.isBlank()) {
            state = AdState.FAILED
            message = "MISSING Ad Unit ID - set it in AdsConfig.kt"
            AdsManager.log("$name: Ad Unit ID missing in AdsConfig.kt")
            return
        }
        if (!(state == AdState.IDLE || state == AdState.COMPLETED || state == AdState.FAILED)) return
        state = AdState.LOADING
        message = "Loading..."
        AdsManager.log("$name: load($placementId)")
        UnityAds.load(placementId, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String?) = ui {
                state = AdState.LOADED
                message = "Loaded - ready to show"
                AdsManager.log("$name: loaded")
            }

            override fun onUnityAdsFailedToLoad(
                placementId: String?,
                error: UnityAds.UnityAdsLoadError?,
                msg: String?
            ) = ui {
                state = AdState.FAILED
                message = "Load failed: ${error?.name} - $msg"
                AdsManager.log("$name: load FAILED ${error?.name}: $msg")
            }
        })
    }

    fun show(activity: Activity) {
        if (state != AdState.LOADED) {
            AdsManager.log("$name: show blocked (not loaded)")
            return
        }
        state = AdState.SHOWING
        message = "Showing..."
        UnityAds.show(activity, placementId, UnityAdsShowOptions(), object : IUnityAdsShowListener {
            override fun onUnityAdsShowFailure(
                placementId: String?,
                error: UnityAds.UnityAdsShowError?,
                msg: String?
            ) = ui {
                state = AdState.FAILED
                message = "Show failed: ${error?.name} - $msg"
                AdsManager.log("$name: show FAILED ${error?.name}: $msg")
                scheduleReload()
            }

            override fun onUnityAdsShowStart(placementId: String?) = ui {
                AdsManager.log("$name: show started")
            }

            override fun onUnityAdsShowClick(placementId: String?) = ui {
                AdsManager.log("$name: clicked")
            }

            override fun onUnityAdsShowComplete(
                placementId: String?,
                completion: UnityAds.UnityAdsShowCompletionState?
            ) = ui {
                state = AdState.COMPLETED
                if (rewarded) {
                    if (completion == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                        AdsManager.addCoins(AdsConfig.REWARD_COINS)
                        message = "Completed - +${AdsConfig.REWARD_COINS} demo coins"
                    } else {
                        message = "Closed (${completion?.name}) - no reward"
                    }
                } else {
                    message = "Closed (${completion?.name})"
                }
                AdsManager.log("$name: closed, state=${completion?.name}")
                scheduleReload()
            }
        })
    }

    private fun scheduleReload() {
        mainHandler.postDelayed({
            if (state == AdState.COMPLETED || state == AdState.FAILED) {
                state = AdState.IDLE
                load()
            }
        }, 1500)
    }

    fun reset() {
        state = AdState.IDLE
        message = "Not loaded"
    }
}

object AdsManager {
    var initialized by mutableStateOf(false)
    var initializing by mutableStateOf(false)
    var sdkStatus by mutableStateOf("Not initialized")
    var coins by mutableIntStateOf(0)
    val logs = mutableStateListOf<String>()

    val interstitial = AdSlot("Interstitial", AdsConfig.INTERSTITIAL_ID, rewarded = false)
    val rewarded = AdSlot("Rewarded", AdsConfig.REWARDED_ID, rewarded = true)

    var bannerView by mutableStateOf<BannerView?>(null)
    var bannerState by mutableStateOf(AdState.IDLE)
    var bannerMessage by mutableStateOf("Not loaded")
    var bannerVisible by mutableStateOf(false)

    private val pending = mutableListOf<() -> Unit>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun log(text: String) = ui {
        logs.add(0, "${timeFmt.format(Date())}  $text")
        while (logs.size > 100) logs.removeAt(logs.size - 1)
    }

    fun addCoins(n: Int) { coins += n }

    /** Runs [block] once the SDK is initialized, initializing first if needed. */
    fun whenReady(context: Context, block: () -> Unit) {
        if (initialized) { block(); return }
        pending.add(block)
        initialize(context)
    }

    fun initialize(context: Context) {
        if (initialized || initializing) {
            log("Init skipped (already ${if (initialized) "initialized" else "in progress"})")
            return
        }
        if (AdsConfig.ANDROID_GAME_ID.isBlank()) {
            sdkStatus = "Failed: Game ID missing"
            return
        }
        val app = context.applicationContext
        initializing = true
        sdkStatus = "Initializing..."
        log("initialize(gameId=${AdsConfig.ANDROID_GAME_ID}, testMode=${AdsConfig.TEST_MODE})")

        AdsConfig.CONSENT?.let { consent ->
            val gdpr = MetaData(app)
            gdpr.set("gdpr.consent", consent)
            gdpr.commit()
            val privacy = MetaData(app)
            privacy.set("privacy.consent", consent)
            privacy.commit()
            log("Consent metadata sent: $consent")
        }

        UnityAds.initialize(app, AdsConfig.ANDROID_GAME_ID, AdsConfig.TEST_MODE,
            object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() = ui {
                    initializing = false
                    initialized = true
                    sdkStatus = "Initialized"
                    log("SDK initialized")
                    val run = pending.toList()
                    pending.clear()
                    run.forEach { it() }
                }

                override fun onInitializationFailed(
                    error: UnityAds.UnityAdsInitializationError?,
                    message: String?
                ) = ui {
                    initializing = false
                    pending.clear()
                    sdkStatus = "Failed: ${error?.name} - $message"
                    log("Init FAILED ${error?.name}: $message")
                }
            })
    }

    // ---------------- Banner ----------------

    fun loadBanner(activity: Activity) {
        if (bannerState == AdState.LOADING) return
        if (AdsConfig.BANNER_ID.isBlank()) {
            bannerState = AdState.FAILED
            bannerMessage = "MISSING Ad Unit ID - set it in AdsConfig.kt"
            log("Banner: Ad Unit ID missing in AdsConfig.kt")
            return
        }
        whenReady(activity) {
            destroyBanner()
            bannerState = AdState.LOADING
            bannerMessage = "Loading..."
            log("Banner: load(${AdsConfig.BANNER_ID})")
            val view = BannerView(activity, AdsConfig.BANNER_ID, UnityBannerSize(320, 50))
            view.setListener(object : BannerView.IListener {
                override fun onBannerLoaded(bannerAdView: BannerView?) = ui {
                    bannerState = AdState.LOADED
                    bannerMessage = "Loaded - tap Show Banner"
                    log("Banner: loaded")
                }

                override fun onBannerShown(bannerAdView: BannerView?) = ui {
                    log("Banner: shown")
                }

                override fun onBannerClick(bannerAdView: BannerView?) = ui {
                    log("Banner: clicked")
                }

                override fun onBannerFailedToLoad(bannerAdView: BannerView?, errorInfo: BannerErrorInfo?) = ui {
                    bannerState = AdState.FAILED
                    bannerVisible = false
                    bannerMessage = "Load failed: ${errorInfo?.errorMessage}"
                    log("Banner: load FAILED ${errorInfo?.errorCode}: ${errorInfo?.errorMessage}")
                }

                override fun onBannerLeftApplication(bannerAdView: BannerView?) = ui {
                    log("Banner: left application")
                }
            })
            bannerView = view
            view.load()
        }
    }

    fun showBanner() {
        if (bannerState != AdState.LOADED || bannerView == null) {
            log("Banner: show blocked (not loaded)")
            return
        }
        bannerVisible = true
        bannerState = AdState.SHOWING
        bannerMessage = "Showing"
    }

    fun hideBanner() {
        bannerVisible = false
        if (bannerState == AdState.SHOWING) {
            bannerState = AdState.LOADED
            bannerMessage = "Hidden (still loaded)"
        }
    }

    fun destroyBanner() {
        bannerVisible = false
        bannerView?.destroy()
        bannerView = null
        bannerState = AdState.IDLE
        bannerMessage = "Not loaded"
    }

    // ---------------- Reset ----------------

    fun resetAndReload(activity: Activity) {
        log("Reset / Reload")
        destroyBanner()
        interstitial.reset()
        rewarded.reset()
        if (initialized) {
            interstitial.load()
            rewarded.load()
        } else {
            whenReady(activity) { interstitial.load(); rewarded.load() }
        }
    }
}

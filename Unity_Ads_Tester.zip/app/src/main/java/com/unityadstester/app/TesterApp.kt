package com.unityadstester.app

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val Bg = Color(0xFF0F1115)
private val CardBg = Color(0xFF1A1D24)

private val Scheme = darkColorScheme(
    primary = Color(0xFF8AB4FF),
    onPrimary = Color(0xFF00224D),
    background = Bg,
    surface = Bg,
    onBackground = Color(0xFFE6E8EE),
    onSurface = Color(0xFFE6E8EE)
)

private fun stateColor(s: AdState) = when (s) {
    AdState.IDLE -> Color(0xFF8A90A0)
    AdState.LOADING -> Color(0xFFFFC857)
    AdState.LOADED -> Color(0xFF5BD6A0)
    AdState.SHOWING -> Color(0xFF8AB4FF)
    AdState.COMPLETED -> Color(0xFF5BD6A0)
    AdState.FAILED -> Color(0xFFFF6B6B)
}

@Composable
fun TesterApp() {
    val activity = LocalContext.current as Activity
    MaterialTheme(colorScheme = Scheme) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Header()
                StatusCard(activity)
                SlotCard("1. Interstitial Ads", AdsManager.interstitial,
                    "Initialize / Load Interstitial", "Show Interstitial", activity)
                SlotCard("2. Rewarded Ads", AdsManager.rewarded,
                    "Load Rewarded Ad", "Watch Rewarded Ad", activity)
                BannerCard(activity)
                DiagnosticsCard()
            }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Canvas(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF8AB4FF))) {
            val p = Path().apply {
                moveTo(size.width * 0.38f, size.height * 0.28f)
                lineTo(size.width * 0.38f, size.height * 0.72f)
                lineTo(size.width * 0.74f, size.height * 0.5f)
                close()
            }
            drawPath(p, Color(0xFF0F1115))
        }
        Column {
            Text("Unity Ads Tester", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Android ad integration test", fontSize = 12.sp, color = Color(0xFF8A90A0))
        }
    }
}

@Composable
private fun Panel(title: String, content: @Composable () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardBg)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            content()
        }
    }
}

@Composable
private fun StatusLine(label: String, value: String, color: Color = Color(0xFFE6E8EE)) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, color = Color(0xFF8A90A0), fontSize = 13.sp)
        Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StateRow(state: AdState, message: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Surface(shape = CircleShape, color = stateColor(state), modifier = Modifier.size(10.dp)) {}
        Text(state.name, color = stateColor(state), fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
    Text(message, fontSize = 13.sp)
}

@Composable
private fun StatusCard(activity: Activity) {
    Panel("Status") {
        StatusLine("Network:", "Unity Ads by Unity Technologies")
        StatusLine("Game ID (Android):", AdsConfig.ANDROID_GAME_ID)
        StatusLine("Mode:", if (AdsConfig.TEST_MODE) "TEST MODE" else "PRODUCTION")
        StatusLine(
            "SDK:", AdsManager.sdkStatus,
            when {
                AdsManager.initialized -> Color(0xFF5BD6A0)
                AdsManager.sdkStatus.startsWith("Failed") -> Color(0xFFFF6B6B)
                else -> Color(0xFFFFC857)
            }
        )
        StatusLine("Interstitial:", AdsManager.interstitial.state.name, stateColor(AdsManager.interstitial.state))
        StatusLine("Rewarded:", AdsManager.rewarded.state.name, stateColor(AdsManager.rewarded.state))
        StatusLine("Banner:", AdsManager.bannerState.name, stateColor(AdsManager.bannerState))
        StatusLine("Demo coins:", AdsManager.coins.toString())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!AdsManager.initialized) {
                Button(
                    onClick = { AdsManager.initialize(activity) },
                    enabled = !AdsManager.initializing
                ) { Text("Initialize SDK") }
            }
            OutlinedButton(onClick = { AdsManager.resetAndReload(activity) }) { Text("Reset / Reload") }
        }
    }
}

@Composable
private fun SlotCard(title: String, slot: AdSlot, loadLabel: String, showLabel: String, activity: Activity) {
    Panel(title) {
        StateRow(slot.state, slot.message)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { slot.requestLoad(activity) }, enabled = slot.canLoad) { Text(loadLabel) }
            Button(onClick = { slot.show(activity) }, enabled = slot.state == AdState.LOADED) { Text(showLabel) }
        }
    }
}

@Composable
private fun BannerCard(activity: Activity) {
    Panel("3. Banner Ads") {
        StateRow(AdsManager.bannerState, AdsManager.bannerMessage)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { AdsManager.loadBanner(activity) },
                enabled = AdsManager.bannerState != AdState.LOADING && !AdsManager.initializing
            ) { Text("Load Banner") }
            Button(
                onClick = { AdsManager.showBanner() },
                enabled = AdsManager.bannerState == AdState.LOADED
            ) { Text("Show Banner") }
            OutlinedButton(
                onClick = { AdsManager.hideBanner() },
                enabled = AdsManager.bannerVisible
            ) { Text("Hide") }
        }
        // Fixed 320x50 container; the banner is attached only when loaded.
        val banner = AdsManager.bannerView
        val visible = AdsManager.bannerVisible
        AndroidView(
            modifier = Modifier.size(320.dp, 50.dp).background(Color(0xFF12141A)),
            factory = { ctx -> FrameLayout(ctx) },
            update = { container ->
                container.removeAllViews()
                if (banner != null) {
                    (banner.parent as? ViewGroup)?.removeView(banner)
                    container.addView(banner)
                }
                container.visibility = if (visible && banner != null) View.VISIBLE else View.INVISIBLE
            }
        )
    }
}

@Composable
private fun DiagnosticsCard() {
    Panel("Diagnostics (newest first)") {
        if (AdsManager.logs.isEmpty()) {
            Text("No callbacks yet.", fontSize = 12.sp, color = Color(0xFF8A90A0))
        } else {
            AdsManager.logs.take(40).forEach {
                Text(it, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

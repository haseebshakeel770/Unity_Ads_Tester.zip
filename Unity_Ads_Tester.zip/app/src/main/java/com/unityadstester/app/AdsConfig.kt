package com.unityadstester.app

/**
 * ALL Unity Ads settings live here. Edit only this file.
 * Android ONLY. No iOS IDs are used anywhere in this project.
 *
 * Leave an Ad Unit ID as "" and the app will show "MISSING" for that format
 * instead of guessing an ID.
 */
object AdsConfig {
    const val ANDROID_GAME_ID = "6225197"

    // true = Unity test ads (use for all development)
    const val TEST_MODE = true

    // Paste your exact Android Ad Unit (placement) IDs from the Unity dashboard:
    const val INTERSTITIAL_ID = ""   // TODO: paste Android Interstitial Ad Unit ID
    const val REWARDED_ID = ""       // TODO: paste Android Rewarded Ad Unit ID
    const val BANNER_ID = ""         // TODO: paste Android Banner Ad Unit ID

    const val REWARD_COINS = 10

    // Consent: this app does NOT collect consent itself. Leave null to send nothing,
    // or set true/false ONLY if you have obtained the user's actual choice elsewhere.
    val CONSENT: Boolean? = null
}
